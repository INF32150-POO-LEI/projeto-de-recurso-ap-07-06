package PosicoesDimensoes;

/**
 * A classe Posicao representa uma posição em um sistema de coordenadas bidimensional, com as coordenadas x e y.
 */
public class Posicao {

    private int x;
    private int y;

    /**
     * Construtor da classe Posicao.
     *
     * @param x a coordenada x da posição.
     * @param y a coordenada y da posição.
     */
    public Posicao(int x, int y) {

        this.x = x;
        this.y = y;
    }

    /**
     * Obtém a coordenada x da posição.
     *
     * @return a coordenada x.
     */
    public int getX() {
        return x;
    }

    /**
     * Obtém a coordenada y da posição.
     *
     * @return a coordenada y.
     */
    public int getY() {
        return y;
    }

    /**
     * Define a coordenada x da posição.
     *
     * @param x a coordenada x a ser definida.
     */
    public void setX(int x) {
        this.x = x;
    }

    /**
     * Define a coordenada y da posição.
     *
     * @param y a coordenada y a ser definida.
     */
    public void setY(int y) {
        this.y = y;
    }
}
