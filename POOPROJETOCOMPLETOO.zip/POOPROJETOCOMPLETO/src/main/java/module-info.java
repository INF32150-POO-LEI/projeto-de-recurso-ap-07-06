module com.example.pooprojetocompleto {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.kordamp.ikonli.javafx;
    requires org.junit.jupiter.api;

    opens com.example.pooprojetocompleto to javafx.fxml;
    exports com.example.pooprojetocompleto;
    exports Embalagens;
    opens Embalagens to javafx.fxml;
    exports Veiculos;
    opens Veiculos to javafx.fxml;
    exports Sensores;
    opens Sensores to javafx.fxml;
    exports Produtos;
    opens Produtos to javafx.fxml;
    exports Erros;
    opens Erros to javafx.fxml;
    exports PosicoesDimensoes;
    opens PosicoesDimensoes to javafx.fxml;
    exports CentroDistribuicao;
    opens CentroDistribuicao to javafx.fxml;
}