package Erros;

/**
 * A enumeração CodigoErro representa os códigos de erro utilizados no projeto.
 * Ela define os possíveis códigos de erro e fornece uma representação em String para cada um deles.
 */
public enum CodigoErro {
    SIZE_NOT_SUPPORTED,
    TYPE_NOT_SUPPORTED,
    EMBALAGEM_IS_FULL,
    NO_SENSOR_INSTALLED,
    EMBALAGEM_REPETIDA,
    CAIXA_NAO_EXISTE,
    PRODUTO_REPETIDO,
    LOAD_CSV_ERRO,
    CAPACIDADE_CARRO_CHEIA,
    CARRO_VAZIO,
    DESTINO_LONGE,
    ESPACO_OCUPADO;

    /**
     * Retorna uma representação em String do código de erro.
     *
     * @return Uma representação em String do código de erro.
     */
    @Override
    public String toString() {
        switch (this) {
            case SIZE_NOT_SUPPORTED:
                return "O tamanho não é válido";
            case EMBALAGEM_IS_FULL:
                return "A embalagem já está cheia";
            case TYPE_NOT_SUPPORTED:
                return "O tipo de produto não é válido para esta embalagem";
            case NO_SENSOR_INSTALLED:
                return "Nenhum sensor está instalado no momento";
            case PRODUTO_REPETIDO:
                return "O produto já está dentro da embalagem";
            case EMBALAGEM_REPETIDA:
                return "A Caixa de cartão já está dentro da Palete";
            case CAIXA_NAO_EXISTE:
                return "A caixa não está na palete.";
            case LOAD_CSV_ERRO:
                return "Erro ao ler o ficheiro CSV";
            case CAPACIDADE_CARRO_CHEIA:
                return"A capacidade do carro está a exceder o peso";
            case CARRO_VAZIO:
                return "O carro está vazio de momento";
            case DESTINO_LONGE:
                return "O destino está longe demais para interagir com o mesmo;";
            case ESPACO_OCUPADO:
                return "Esse espaço se encontra ocupado por um objeto";
        }
        return "";
    }
}
