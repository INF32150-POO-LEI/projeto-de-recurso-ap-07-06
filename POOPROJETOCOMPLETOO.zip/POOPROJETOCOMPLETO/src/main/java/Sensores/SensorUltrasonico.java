package Sensores;

/**
 * A classe SensorUltrasonico implementa a interface Sensor e representa um sensor ultrassônico.
 * Ela possui um alcance e um ângulo de visão específicos.
 */
public class SensorUltrasonico implements Sensor {
    private static final int ALCANCE = 8; // metros
    private static final int ANGULO_VISAO = 180; // graus

    /**
     * Realiza a detecção utilizando o sensor ultrassônico.
     * Imprime informações sobre o alcance e o ângulo de visão do sensor.
     */
    @Override
    public void detectar() {
        System.out.println("Detectando com Ultrassônico até " + ALCANCE + " metros com um ângulo de visão de " + ANGULO_VISAO + " graus");
    }
}
