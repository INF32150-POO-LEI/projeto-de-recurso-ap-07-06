package Produtos;

/**
 * A classe Produto representa um produto a ser embalado e armazenado.
 */
public class Produto {
    private static int idNumero;
    private String idFinal;
    private String nome;
    private double peso;
    private EnumProdutoTipo tipo;
    private EnumProdutoTamanho tamanho;

    /**
     * Construtor da classe Produto.
     *
     * @param nome    o nome do produto.
     * @param peso    o peso do produto.
     * @param tipo    o tipo do produto.
     * @param tamanho o tamanho do produto.
     */
    public Produto(String nome, double peso, EnumProdutoTipo tipo, EnumProdutoTamanho tamanho) {
        this.nome = nome;
        this.peso = peso;
        this.tipo = tipo;
        validateProduto(tamanho, tipo);
        this.idFinal = tipo.toString() + (++idNumero);
    }

    /**
     * Obtém o nome do produto.
     *
     * @return o nome do produto.
     */
    public String getNome() {
        return nome;
    }

    /**
     * Define o nome do produto.
     *
     * @param nome o nome do produto a ser definido.
     */
    public void setNome(String nome) {
        this.nome = nome;
    }

    /**
     * Obtém o peso do produto.
     *
     * @return o peso do produto.
     */
    public double getPeso() {
        return peso;
    }

    /**
     * Define o peso do produto.
     *
     * @param peso o peso do produto a ser definido.
     */
    public void setPeso(double peso) {
        this.peso = peso;
    }

    /**
     * Obtém o tipo do produto.
     *
     * @return o tipo do produto.
     */
    public EnumProdutoTipo getTipo() {
        return tipo;
    }

    /**
     * Define o tipo do produto.
     *
     * @param tipo o tipo do produto a ser definido.
     */
    public void setTipo(EnumProdutoTipo tipo) {
        this.tipo = tipo;
    }

    /**
     * Obtém o tamanho do produto.
     *
     * @return o tamanho do produto.
     */
    public EnumProdutoTamanho getTamanho() {
        return tamanho;
    }

    /**
     * Define o tamanho do produto.
     *
     * @param tamanho o tamanho do produto a ser definido.
     */
    public void setTamanho(EnumProdutoTamanho tamanho) {
        this.tamanho = tamanho;
    }

    /**
     * Obtém o ID final do produto.
     *
     * @return o ID final do produto.
     */
    public String getIdFinal() {
        return idFinal;
    }

    /**
     * Valida e determina o tamanho do produto com base no tipo.
     *
     * @param tamanho o tamanho inicial do produto.
     * @param tipo    o tipo do produto.
     */
    private void validateProduto(EnumProdutoTamanho tamanho, EnumProdutoTipo tipo) {
        if (tipo == EnumProdutoTipo.LIVRO || tipo == EnumProdutoTipo.ACESSORIO || tipo == EnumProdutoTipo.ROUPA) {
            this.tamanho = EnumProdutoTamanho.PEQUENO;
        } else {
            this.tamanho = tamanho;
        }
    }

    /**
     * Reseta o número de ID dos produtos.
     */
    public static void resetIdNumber() {
        idNumero = 0;
    }
}
