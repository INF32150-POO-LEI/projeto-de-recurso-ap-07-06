package Embalagens;

import Produtos.Produto;

/**
 * A interface Embalavel define um contrato para objetos que podem ser embalados.
 */
public interface Embalavel {
    /**
     * Embala um produto.
     *
     * @param produto o produto a ser embalado.
     */
    void embalar(Produto produto);
}
