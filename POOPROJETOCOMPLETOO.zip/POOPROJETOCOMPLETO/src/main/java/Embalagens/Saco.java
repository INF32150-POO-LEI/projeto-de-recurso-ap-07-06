package Embalagens;

import Erros.CodigoErro;
import Erros.ProjetoIllegalArgumentException;
import Produtos.EnumProdutoTamanho;
import Produtos.EnumProdutoTipo;
import Produtos.Produto;

import java.util.LinkedList;

/**
 * A classe Saco representa uma embalagem do tipo saco.
 */
public class Saco extends Embalagem implements Embalavel,Transportavel {
    public Saco() {
        super();
        this.tipo = EnumEmbalagemTipo.SACO;
        this.idFinal = tipo.toString() + (++idNumero);
        produtos = new LinkedList<Produto>();
    }

    public double getPesoTotal() {
        if (!produtos.isEmpty()) {
            return produtos.get(0).getPeso();
        } else {
            return 0.0;
        }
    }

    /**
     * Embala um produto no saco.
     *
     * @param produto o produto a ser embalado.
     * @throws ProjetoIllegalArgumentException se o saco estiver cheio ou se o tamanho ou tipo do produto não for suportado.
     */
    @Override
    public void embalar(Produto produto) {
        if (!produtos.isEmpty()) {
            throw new ProjetoIllegalArgumentException(CodigoErro.EMBALAGEM_IS_FULL);
        }
        if (produto.getTamanho() == EnumProdutoTamanho.GRANDE || produto.getTipo() == EnumProdutoTipo.LIVRO) {
            throw new ProjetoIllegalArgumentException(CodigoErro.TYPE_NOT_SUPPORTED);
        } else {
            produtos.add(produto);
        }
    }
}
