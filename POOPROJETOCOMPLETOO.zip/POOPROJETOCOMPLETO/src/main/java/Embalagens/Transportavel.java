package Embalagens;

public interface Transportavel {
    public double getPesoTotal();
}
