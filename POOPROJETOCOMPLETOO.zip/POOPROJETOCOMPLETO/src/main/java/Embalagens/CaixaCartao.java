package Embalagens;

import Erros.CodigoErro;
import Erros.ProjetoIllegalArgumentException;
import Produtos.EnumProdutoTamanho;
import Produtos.Produto;

import java.util.LinkedList;

/**
 * A classe CaixaCartao representa uma caixa de cartão como uma subclasse de Embalagem e implementa a interface Embalavel.
 */
public class CaixaCartao extends Embalagem implements Embalavel {

    /**
     * Construtor padrão da classe CaixaCartao.
     * Inicializa os atributos e configura o tipo e o ID da embalagem.
     */
    public CaixaCartao() {
        super();
        this.tipo = EnumEmbalagemTipo.CAIXACARTAO;
        this.idFinal = tipo.toString() + (++idNumero);
        produtos = new LinkedList<Produto>();
    }
    public double getPesoTotal() {
        double pesoTotal = 0.0;
        for (Produto produto : produtos) {
            pesoTotal += produto.getPeso();
        }
        return pesoTotal;
    }

    /**
     * Método para embalar um produto na caixa de cartão.
     *
     * @param produto o produto a ser embalado na caixa de cartão.
     * @throws ProjetoIllegalArgumentException se a caixa estiver cheia, se o produto for repetido, ou se o tamanho do produto não for suportado.
     */
    @Override
    public void embalar(Produto produto) throws ProjetoIllegalArgumentException {
        if (!produtos.isEmpty() && produtos.get(0).getTamanho() == EnumProdutoTamanho.GRANDE) {
            throw new ProjetoIllegalArgumentException(CodigoErro.EMBALAGEM_IS_FULL);
        }

        if (!produtos.isEmpty() && produto.getTamanho() == EnumProdutoTamanho.GRANDE) {
            throw new ProjetoIllegalArgumentException(CodigoErro.EMBALAGEM_IS_FULL);
        }

        if (produtos.size() == 10) {
            throw new ProjetoIllegalArgumentException(CodigoErro.EMBALAGEM_IS_FULL);
        }

        if (produtos.contains(produto)) {
            throw new ProjetoIllegalArgumentException(CodigoErro.PRODUTO_REPETIDO);
        } else {
            produtos.add(produto);
        }
    }
}
