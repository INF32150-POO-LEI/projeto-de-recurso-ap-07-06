package CentroDistribuicao;

import PosicoesDimensoes.Posicao;

public interface Descarregavel {
    void removerTodasEmbalagens();
    void removerTodosProdutosDasEmbalagens();

    Posicao getPosicao();
}
