package CentroDistribuicao;

import PosicoesDimensoes.Dimensao;
import PosicoesDimensoes.Posicao;

import java.util.LinkedList;

/**
 * A classe LocalArmazenamento representa um local de armazenamento que herda as características de um local com posição e dimensão.
 * Ele também possui uma lista encadeada de prateleiras.
 */
public class LocalArmazenamento extends Local {

    private LinkedList<Prateleira> prateleiras;

    /**
     * Construtor da classe LocalArmazenamento.
     *
     * @param posicao   a posição do local de armazenamento.
     * @param dimensao  a dimensão do local de armazenamento.
     */
    public LocalArmazenamento(Posicao posicao, Dimensao dimensao) {
        super(posicao, dimensao);
        prateleiras = new LinkedList<Prateleira>();
    }
}
