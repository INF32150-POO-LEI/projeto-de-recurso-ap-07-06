package CentroDistribuicao;

import PosicoesDimensoes.Dimensao;
import PosicoesDimensoes.Posicao;
import Veiculos.Veiculo;
import java.util.LinkedList;

public class CentroDistribuicao {
    private LocalRecolha localRecolha;
    private LocalEntrega localEntrega;
    private LocalArmazenamento localArmazenamento;
    private Posicao posicao;
    private Dimensao dimensao;
    private Tiles[][] grid;
    private LinkedList<Veiculo> veiculos;

    private Posicao[] paletes;
    private Posicao[] prateleiras;

    public CentroDistribuicao(Dimensao dimensao,LinkedList<Veiculo> veiculos, Posicao[] paletes,Posicao[] prateleiras)
    {   this.dimensao=dimensao;
        this.localRecolha= new LocalRecolha(new Posicao(0,5),new Dimensao(dimensao.getComprimento()/2, dimensao.getLargura()/3));
        this.localEntrega = new LocalEntrega(new Posicao(dimensao.getLargura()- dimensao.getLargura()/3, 5), new Dimensao(dimensao.getComprimento()/2, dimensao.getLargura()/3));
        this.localArmazenamento = new LocalArmazenamento(new Posicao(dimensao.getLargura()/3, 2), new Dimensao(dimensao.getComprimento()-5, dimensao.getLargura()/3));
        this.veiculos=veiculos;
        this.paletes=paletes;
        this.prateleiras=prateleiras;
        encherCentroDistribuicao();
    }

    public LocalRecolha getLocalRecolha() {
        return localRecolha;
    }

    public LocalEntrega getLocalEntrega() {
        return localEntrega;
    }

    public LocalArmazenamento getLocalArmazenamento() {
        return localArmazenamento;
    }

    public Posicao getPosicao() {
        return posicao;
    }

    public Dimensao getDimensao() {
        return dimensao;
    }
    /**
     * Populates board with tiles and zones
     */
    private void encherCentroDistribuicao() {
        int x = this.getDimensao().getLargura();
        int y = this.getDimensao().getComprimento();
        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                grid[i][j] = new Tiles(i, j, TilesTipo.LIVRE);
            }
        }
        addZones();

    }

    /**
     * Adds Pickup, delivery, pallets and shelves zones to board
     */
    private void addZones() {
        int x = this.getDimensao().getLargura();
        int y = this.getDimensao().getComprimento();
        Posicao paleteP1 = paletes[0];
        Posicao paleteP2 = paletes[1];
        Posicao prateleiraP2 = prateleiras[0];
        Posicao prateleiraP1 = prateleiras[1];
        int index = 0;
        TilesTipo veiculo;
        Posicao posicao;

        for (int i = 0; i < x; i++) {
            for (int j = 0; j < y; j++) {
                if ((i < (x / 2) && j == 0)) {
                    grid[i][j] = new Tiles(i, j, TilesTipo.RECOLHA);
                }
                if ((i >= (x / 2) && j == y - 1)) {
                    grid[i][j] = new Tiles(i, j, TilesTipo.ENTREGA);
                }
                if (i >= paleteP1.getX() && j >= paleteP1.getY()) {
                    if (i <= paleteP2.getX() && j <= paleteP2.getY()) {
                        grid[i][j] = new Tiles(i, j, TilesTipo.PALETES);
                    }
                }
                if (i >= prateleiraP1.getX() && j >= prateleiraP1.getY()) {
                    if (i <= prateleiraP1.getX() && j <= prateleiraP2.getY()) {
                        grid[i][j] = new Tiles(i, j, TilesTipo.PRATELEIRAS);
                    }
                }
                if (index == veiculos.size()) {
                    return;
                }

            }
        }
    }

    /**
     * Coloca os veiculos no tabuleiro
     *
     */
}
