package CentroDistribuicao;

import PosicoesDimensoes.Dimensao;
import PosicoesDimensoes.Posicao;

/**
 * A classe Local representa um local com uma posição e uma dimensão.
 */
public abstract class Local {

    protected Posicao posicao;
    protected Dimensao dimensao;

    /**
     * Construtor da classe Local.
     *
     * @param posicao   a posição do local.
     * @param dimensao  a dimensão do local.
     */
    public Local(Posicao posicao, Dimensao dimensao) {
        this.posicao = posicao;
        this.dimensao = dimensao;
    }

    /**
     * Obtém a posição do local.
     *
     * @return a posição do local.
     */
    public Posicao getPosicao() {
        return posicao;
    }

    /**
     * Obtém a dimensão do local.
     *
     * @return a dimensão do local.
     */
    public Dimensao getDimensao() {
        return dimensao;
    }

    /**
     * Define a posição do local.
     *
     * @param posicao a posição a ser definida.
     */
    public void setPosicao(Posicao posicao) {
        this.posicao = posicao;
    }

    /**
     * Define a dimensão do local.
     *
     * @param dimensao a dimensão a ser definida.
     */
    public void setDimensao(Dimensao dimensao) {
        this.dimensao = dimensao;
    }
}
