package CentroDistribuicao;


import PosicoesDimensoes.Posicao;
import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;


public class Tiles extends StackPane{
    private final Posicao posicao;
    private boolean espacoOcupado;
    private TilesTipo tileTipo;
    private Rectangle retangulo;




    public Tiles(int x, int y, TilesTipo tileTipo){
        posicao = new Posicao(x, y);
        espacoOcupado = false;
        this.tileTipo = tileTipo;

        retangulo = new Rectangle();
        switch(tileTipo){
            case LIVRE:
                retangulo.setFill(Color.WHITE);
                break;
            case CARRINHODETRANSPORTE:
                retangulo.setFill(Color.RED);
                break;
            case PRATELEIRAS:
                retangulo.setFill(Color.BROWN);
                break;
            case PALETES:
                retangulo.setFill(Color.BLACK);
                break;
            case RECOLHA:
                retangulo.setFill(Color.DODGERBLUE);
                break;
            case ENTREGA:
                retangulo.setFill(Color.CRIMSON);
                break;
            case VEICULOREBOCADOR:
                retangulo.setFill(Color.GREEN);
                break;
            case CARRINHOGUIADOAUTOMATICO:
                retangulo.setFill(Color.YELLOW);
                break;
            case TRANSPORTADORCARGAUNITARIA:
                retangulo.setFill(Color.PINK);
                break;
        }
        retangulo.setStroke(Color.BLACK);
        getChildren().add(retangulo);

    }


    public Posicao getPosicao() {
        return posicao;
    }


    public boolean isEspacoOcupado() {
        return espacoOcupado;
    }


    public void setEspacoOcupado(Object o) {
        if (espacoOcupado != true) {
            espacoOcupado = true;
        }
    }


    public TilesTipo getType() {
        return tileTipo;
    }


    public void setType(TilesTipo tilesTipo) {
        this.tileTipo = tilesTipo;
    }


    public TilesTipo getTilesTipo() {
        return tileTipo;
    }

    public Rectangle getRec() {
        return retangulo;
    }



}
