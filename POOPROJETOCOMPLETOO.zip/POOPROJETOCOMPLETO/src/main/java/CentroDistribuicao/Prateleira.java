package CentroDistribuicao;

import Embalagens.Embalagem;
import PosicoesDimensoes.Posicao;

import java.util.LinkedList;

/**
 * A classe Prateleira representa uma prateleira onde as embalagens podem ser armazenadas.
 */
public class Prateleira implements Descarregavel{
    private static int id;
    private LinkedList<Embalagem> embalagens;
    private Posicao posicao;

    /**
     * Construtor da classe Prateleira.
     *
     * @param posicao a posição da prateleira.
     */
    public Prateleira(Posicao posicao) {
        this.posicao = posicao;
        this.id = ++id;
        embalagens = new LinkedList<Embalagem>();
    }

    public LinkedList<Embalagem> getEmbalagens() {
        return embalagens;
    }
    public void removerTodasEmbalagens() {
        embalagens.clear();
    }
    public void removerTodosProdutosDasEmbalagens() {
        for (Embalagem embalagem : embalagens) {
            embalagem.removerTodosProdutos();
        }
    }


    public Posicao getPosicao() {
        return posicao;
    }

}
