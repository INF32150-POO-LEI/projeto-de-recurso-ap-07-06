package Veiculos;

import CentroDistribuicao.TilesTipo;
import Embalagens.Palete;
import Embalagens.Transportavel;
import Erros.CodigoErro;
import Erros.ProjetoIllegalArgumentException;
import PosicoesDimensoes.Posicao;

import java.util.LinkedList;


/**
 * Classe que representa um transportador de carga unitária, que é um tipo específico de veículo.
 * Herda da classe Veiculo.
 */
public class TransportadorDeCargaUnitaria extends Veiculo {

    /**
     * Velocidade máxima do transportador de carga unitária.
     */
    private static final int VELOCIDADE_MAXIMA = 3;
    private static final double CARGA_MAXIMA = 200.0;
    private double cargaAtual;
    private LinkedList<Palete> paletes;

    /**
     * Cria um novo transportador de carga unitária com a posição inicial especificada.
     *
     * @param posicao A posição inicial do transportador.
     */
    public TransportadorDeCargaUnitaria(TilesTipo tilesTipo,Posicao posicao) {
        super(tilesTipo,posicao);
        this.tilesTipo=TilesTipo.TRANSPORTADORCARGAUNITARIA;


    }

    /**
     * Move o transportador de carga unitária nas direções especificadas.
     * Limita a velocidade do movimento de acordo com a velocidade máxima.
     *
     * @param dx deslocamento no eixo X
     * @param dy deslocamento no eixo Y
     */
    @Override
    public void mover(int dx, int dy) {
        dx = Math.min(dx, VELOCIDADE_MAXIMA);
        dy = Math.min(dy, VELOCIDADE_MAXIMA);
        super.mover(dx, dy);
    }
    public void carregar(Palete palete) {

        if (this.cargaAtual + palete.getPesoTotal() <= CARGA_MAXIMA) {
            this.cargaAtual += palete.getPesoTotal();
            paletes.add(palete);

            System.out.println("Carregado " + palete.getPesoTotal() + "kg. Carga atual: " + this.cargaAtual);

        }
        else
        {
            throw new ProjetoIllegalArgumentException(CodigoErro.CAPACIDADE_CARRO_CHEIA);
        }

    }
}
