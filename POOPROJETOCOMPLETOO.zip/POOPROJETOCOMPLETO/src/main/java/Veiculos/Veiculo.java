package Veiculos;

import CentroDistribuicao.TilesTipo;
import Embalagens.Embalagem;
import Erros.CodigoErro;
import PosicoesDimensoes.Posicao;
import Erros.ProjetoIllegalArgumentException;
import Sensores.Sensor;

import java.util.LinkedList;

/**
 * Classe abstrata que representa um veículo.
 */
public abstract class Veiculo {
    protected Sensor sensor;
    protected Posicao posicao;
    protected TilesTipo tilesTipo;

    /**
     * Construtor da classe Veiculo.
     *
     * @param posicao A posição inicial do veículo.
     * @param tilesTipo O tipo de tile.
     */
    Veiculo(TilesTipo tilesTipo,Posicao posicao) {
        this.posicao = posicao;
        this.tilesTipo=tilesTipo;
    }

    /**
     * Obtém a posição atual do veículo.
     *
     * @return A posição atual do veículo.
     */
    public Posicao getPosicao() {
        return this.posicao;
    }

    /**
     * Define a posição do veículo.
     *
     * @param posicao A nova posição do veículo.
     */
    public void setPosicao(Posicao posicao) {
        this.posicao = posicao;
    }

    /**
     * Define o sensor do veículo.
     *
     * @param sensor O sensor a ser definido.
     */
    public void setSensor(Sensor sensor) {
        this.sensor = sensor;
    }

    /**
     * Move o veículo na direção especificada.
     *
     * @param dx O deslocamento no eixo x.
     * @param dy O deslocamento no eixo y.
     */
    public void mover(int dx, int dy) {
        this.posicao.setX(this.posicao.getX() + dx);
        this.posicao.setY(this.posicao.getY() + dy);
        System.out.println("Movido para: " + this.posicao.getX() + ", " + this.posicao.getY());
    }

    /**
     * Para o veículo.
     */
    public void parar() {
        System.out.println("Veículo parado em: " + this.posicao.getX() + ", " + this.posicao.getY());
    }

    /**
     * Executa a detecção usando o sensor do veículo.
     * Lança uma exceção se o sensor não estiver instalado.
     */
    public void detectar() {
        if (this.sensor != null) {
            this.sensor.detectar();
        } else {
            throw new ProjetoIllegalArgumentException(CodigoErro.NO_SENSOR_INSTALLED);
        }
    }
}
