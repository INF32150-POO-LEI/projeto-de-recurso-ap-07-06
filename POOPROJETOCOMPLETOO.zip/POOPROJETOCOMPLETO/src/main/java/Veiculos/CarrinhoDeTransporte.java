package Veiculos;

import CentroDistribuicao.Descarregavel;
import CentroDistribuicao.LocalEntrega;
import CentroDistribuicao.Tiles;
import CentroDistribuicao.TilesTipo;
import Embalagens.Embalagem;
import Embalagens.Transportavel;
import Erros.CodigoErro;
import Erros.ProjetoIllegalArgumentException;
import PosicoesDimensoes.Posicao;

import java.util.LinkedList;

/**
 * A classe CarrinhoDeTransporte representa um carrinho de transporte como um tipo de veículo.
 * Ela herda da classe Veiculo.
 */
public class CarrinhoDeTransporte extends Veiculo {
    private static final double CARGA_MAXIMA = 200;
    private LinkedList<Transportavel> embalagens;
    private double cargaAtual;

    /**
     * Cria uma nova instância de CarrinhoDeTransporte com a posição inicial especificada.
     *
     * @param posicao A posição inicial do carrinho de transporte.
     */
    CarrinhoDeTransporte(TilesTipo tilesTipo, Posicao posicao) {
        super(tilesTipo,posicao);
        this.tilesTipo=TilesTipo.CARRINHODETRANSPORTE;
        this.cargaAtual = 0;
        this.embalagens=new LinkedList<>();
    }


    public void carregar(Descarregavel conteudo, Transportavel embalagem) {

        Posicao posicaoCarrinho = this.getPosicao();
        Posicao posicaoDescarregavel = conteudo.getPosicao();


        int xCarrinho = posicaoCarrinho.getX();
        int yCarrinho = posicaoCarrinho.getY();


        int xDescarregavel = posicaoDescarregavel.getX();
        int yDescarregavel = posicaoDescarregavel.getY();


        boolean estaPerto = (xDescarregavel >= xCarrinho - 1 && xDescarregavel <= xCarrinho + 1)
                && (yDescarregavel >= yCarrinho - 1 && yDescarregavel <= yCarrinho + 1);


        if (!estaPerto) {
            throw new ProjetoIllegalArgumentException(CodigoErro.DESTINO_LONGE);
        }


        if (this.cargaAtual + embalagem.getPesoTotal() <= CARGA_MAXIMA) {
            this.cargaAtual += embalagem.getPesoTotal();
            embalagens.add(embalagem);
            conteudo.removerTodasEmbalagens();
            System.out.println("Carregado " + embalagem.getPesoTotal() + "kg. Carga atual: " + this.cargaAtual);
        }
        else {

        }
    }
    public void descarregar(LocalEntrega localEntrega) {
        Posicao posicaoCarrinho = this.getPosicao();

        int xCarrinho = posicaoCarrinho.getX();
        int yCarrinho = posicaoCarrinho.getY();

        boolean estaPerto = false;
        for (Tiles tile : localEntrega.getTiles()) {
            if (tile.getTilesTipo() == TilesTipo.ENTREGA) {
                Posicao posicaoTile = tile.getPosicao();
                int xTile = posicaoTile.getX();
                int yTile = posicaoTile.getY();

                if ((xTile >= xCarrinho - 1 && xTile <= xCarrinho + 1)
                        && (yTile >= yCarrinho - 1 && yTile <= yCarrinho + 1)) {
                    estaPerto = true;
                    break;
                }
            }
        }

        if (!estaPerto) {
            throw new ProjetoIllegalArgumentException(CodigoErro.DESTINO_LONGE);
        }

        for(Transportavel embalagem:embalagens) {
            localEntrega.getEmbalagens().add((Embalagem) embalagem);
            this.cargaAtual -= embalagem.getPesoTotal();
        }
        embalagens.clear();
    }

}
