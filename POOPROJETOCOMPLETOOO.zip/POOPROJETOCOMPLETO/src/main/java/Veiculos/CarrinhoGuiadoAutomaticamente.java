package Veiculos;

import CentroDistribuicao.Descarregavel;
import CentroDistribuicao.LocalEntrega;
import CentroDistribuicao.Tiles;
import CentroDistribuicao.TilesTipo;
import Erros.CodigoErro;
import Erros.ProjetoIllegalArgumentException;
import PosicoesDimensoes.Posicao;
import Produtos.EnumProdutoTamanho;
import Produtos.Produto;

import java.util.LinkedList;

/**
 * A classe CarrinhoGuiadoAutomaticamente representa um carrinho guiado automaticamente como um tipo de veículo.
 * Ela herda da classe Veiculo.
 */
public class CarrinhoGuiadoAutomaticamente extends Veiculo {
    private static final double CARGA_MAXIMA = 100.0;
    private double cargaAtual;
    private LinkedList<Produto> produtos;

    /**
     * Cria uma nova instância de CarrinhoGuiadoAutomaticamente com a posição inicial especificada.
     *
     * @param posicao A posição inicial do carrinho guiado automaticamente.
     */
    CarrinhoGuiadoAutomaticamente(TilesTipo tilesTipo,Posicao posicao) {
        super(tilesTipo,posicao);
        this.tilesTipo=TilesTipo.CARRINHOGUIADOAUTOMATICO;
        this.cargaAtual = 0;
    }

    /**
     * Carrega o carrinho guiado automaticamente com um determinado peso.
     *
     * @param produto O produto a ser carregado
     */
    public void carregar(Descarregavel conteudo ,Produto produto) {
        Posicao posicaoCarrinho = this.getPosicao();
        Posicao posicaoDescarregavel = conteudo.getPosicao();

        int xCarrinho = posicaoCarrinho.getX();
        int yCarrinho = posicaoCarrinho.getY();

        int xDescarregavel = posicaoDescarregavel.getX();
        int yDescarregavel = posicaoDescarregavel.getY();

        boolean estaPerto = (xDescarregavel >= xCarrinho - 1 && xDescarregavel <= xCarrinho + 1)
                && (yDescarregavel >= yCarrinho - 1 && yDescarregavel <= yCarrinho + 1);

        if (!estaPerto) {
            throw new ProjetoIllegalArgumentException(CodigoErro.DESTINO_LONGE);
        }

        if (produto.getTamanho()==EnumProdutoTamanho.GRANDE) {
            throw new ProjetoIllegalArgumentException(CodigoErro.SIZE_NOT_SUPPORTED);
        }
        else {
            if (this.cargaAtual + produto.getPeso() <= CARGA_MAXIMA) {
                this.cargaAtual += produto.getPeso();
                produtos.add(produto);
                conteudo.removerTodosProdutosDasEmbalagens();
                System.out.println("Carregado " + produto.getPeso() + "kg. Carga atual: " + this.cargaAtual);
            } else {
                System.out.println("Não é possível carregar " + produto.getPeso() + "kg. Excede a carga máxima.");
            }
        }
    }

    public void descarregar(LocalEntrega localEntrega) {
        Posicao posicaoCarrinho = this.getPosicao();

        int xCarrinho = posicaoCarrinho.getX();
        int yCarrinho = posicaoCarrinho.getY();

        boolean estaPerto = false;
        for (Tiles tile : localEntrega.getTiles()) {
            if (tile.getTilesTipo() == TilesTipo.ENTREGA) {
                Posicao posicaoTile = tile.getPosicao();
                int xTile = posicaoTile.getX();
                int yTile = posicaoTile.getY();

                if ((xTile >= xCarrinho - 1 && xTile <= xCarrinho + 1)
                        && (yTile >= yCarrinho - 1 && yTile <= yCarrinho + 1)) {
                    estaPerto = true;
                    break;
                }
            }
        }

        if (!estaPerto) {
            throw new ProjetoIllegalArgumentException(CodigoErro.DESTINO_LONGE);
        }

        if (produtos.isEmpty()) {
            throw new ProjetoIllegalArgumentException(CodigoErro.CARRO_VAZIO);
        } else {
            for (Produto produto : produtos) {
                localEntrega.addProduto(produto);
                this.cargaAtual -= produto.getPeso();
            }

            produtos.clear();
            System.out.println("Descarga concluída. Carrinho agora está vazio.");
        }
    }

}
