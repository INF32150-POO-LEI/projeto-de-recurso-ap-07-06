package Veiculos;

import CentroDistribuicao.TilesTipo;
import PosicoesDimensoes.Posicao;

/**
 * Classe que representa um veículo rebocador.
 */
public class VeiculoRebocador extends Veiculo {
    private CarrinhoDeTransporte carrinhoParaRebocar;

    /**
     * Construtor da classe VeiculoRebocador.
     *
     * @param positionX A posição inicial no eixo x.
     * @param positionY A posição inicial no eixo y.
     */
    public VeiculoRebocador(TilesTipo tilesTipo, int positionX, int positionY) {
        super(tilesTipo,new Posicao(positionX, positionY));
    }

    /**
     * Move o veículo rebocador na direção especificada.
     * Atualiza a posição do veículo rebocador e do carrinho rebocado, se houver.
     *
     * @param dx O deslocamento no eixo x.
     * @param dy O deslocamento no eixo y.
     */
    @Override
    public void mover(int dx, int dy) {
        Posicao novaPosicao = this.getPosicao();
        novaPosicao.setX(novaPosicao.getX() + dx);
        novaPosicao.setY(novaPosicao.getY() + dy);
        this.setPosicao(novaPosicao);
        System.out.println("Movido para: " + this.getPosicao().getX() + ", " + this.getPosicao().getY());

        if (carrinhoParaRebocar != null) {
            Posicao posicaoCarrinho = carrinhoParaRebocar.getPosicao();
            posicaoCarrinho.setX(posicaoCarrinho.getX() + dx);
            posicaoCarrinho.setY(posicaoCarrinho.getY() + dy);
            carrinhoParaRebocar.setPosicao(posicaoCarrinho);
        }
    }

    /**
     * Reboca um carrinho de transporte pelo veículo rebocador.
     *
     * @param carrinhoDeTransporte O carrinho de transporte a ser rebocado.
     */
    public void rebocar(CarrinhoDeTransporte carrinhoDeTransporte) {
        this.carrinhoParaRebocar = carrinhoDeTransporte;
        System.out.println("Rebocando veículo em: " + carrinhoDeTransporte.getPosicao().getX() + ", " + carrinhoDeTransporte.getPosicao().getY());
    }
}
