package PosicoesDimensoes;

/**
 * A classe Dimensao representa as dimensões de um objeto, definidas pelo comprimento e largura.
 */
public class Dimensao {
    private int comprimento;
    private int largura;

    /**
     * Construtor da classe Dimensao.
     *
     * @param comprimento o comprimento do objeto.
     * @param largura     a largura do objeto.
     */
    public Dimensao(int comprimento, int largura) {
        this.comprimento = comprimento;
        this.largura = largura;
    }

    /**
     * Obtém o comprimento do objeto.
     *
     * @return o comprimento do objeto.
     */
    public int getComprimento() {
        return comprimento;
    }

    /**
     * Obtém a largura do objeto.
     *
     * @return a largura do objeto.
     */
    public int getLargura() {
        return largura;
    }
}
