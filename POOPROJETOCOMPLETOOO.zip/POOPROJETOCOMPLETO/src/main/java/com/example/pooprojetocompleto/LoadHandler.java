package com.example.pooprojetocompleto;

import Erros.CodigoErro;
import Erros.ProjetoIllegalArgumentException;
import PosicoesDimensoes.Dimensao;
import Produtos.EnumProdutoTamanho;
import Produtos.EnumProdutoTipo;
import Produtos.Produto;
import Veiculos.Veiculo;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

/**
 * A classe LoadHandler é responsável por carregar os dados a partir de um arquivo CSV.
 */
public class LoadHandler {
    /**
     * Carrega os dados a partir de um arquivo CSV.
     *
     * @return uma lista encadeada de produtos não embalados.
     */
    public LinkedList<Produto> loadProdutos() {
        String csvFile = "F:\\GitihubProjetos\\POOPROJETOFASE1FINAL\\POOPROJETOFASE1FINAL\\src\\produtos.csv";
        String line = "";
        String cvsSplitBy = ",";
        LinkedList<Produto> produtosNaoEmbalados = new LinkedList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            br.readLine(); // Ignora a primeira linha
            while ((line = br.readLine()) != null) {

                String[] produtoStr = line.split(cvsSplitBy);
                String nome = produtoStr[0];
                double peso = Double.parseDouble(produtoStr[1]);
                EnumProdutoTipo tipo = EnumProdutoTipo.valueOf(produtoStr[2].toUpperCase());
                EnumProdutoTamanho tamanho = EnumProdutoTamanho.valueOf(produtoStr[3].toUpperCase());
                Produto produto = new Produto(nome, peso, tipo, tamanho);
                produtosNaoEmbalados.add(produto);
            }
        } catch (IOException e) {
            throw new ProjetoIllegalArgumentException(CodigoErro.LOAD_CSV_ERRO);
        }
        return produtosNaoEmbalados;
    }


    /**
     * Carrega os dados a partir de um arquivo CSV.
     *
     * @return uma dimensão para o Centro de Distribuição..
     */
    public Dimensao loadCentroFromCSV() {
        String csvFile = "F:\\GitihubProjetos\\POOPROJETOFASE1FINAL\\POOPROJETOFASE1FINAL\\src\\centroDimensoes.csv";
        String line = "";
        String cvsSplitBy = ",";
        Dimensao dimensao = null;
        try (BufferedReader br = new BufferedReader(new FileReader(csvFile))) {
            br.readLine(); // Ignora a primeira linha
            if ((line = br.readLine()) != null) {
                String[] centroStr = line.split(cvsSplitBy);
                int comprimento = Integer.parseInt(centroStr[0]);
                int largura = Integer.parseInt(centroStr[1]);
                dimensao = new Dimensao(comprimento, largura);
            }
        } catch (IOException e) {
            throw new ProjetoIllegalArgumentException(CodigoErro.LOAD_CSV_ERRO);
        }
        return dimensao;
    }


}
