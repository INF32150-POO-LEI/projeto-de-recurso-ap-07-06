package com.example.pooprojetocompleto;

import CentroDistribuicao.CentroDistribuicao;
import PosicoesDimensoes.Dimensao;
import Veiculos.Veiculo;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Stage;

import java.util.LinkedList;
/*
public class Main extends Application {

    @Override
    public void start(Stage primaryStage) {
        primaryStage.setTitle("Centro de Distribuição");
        CentroDistribuicao centroDistribuicao;
        LoadHandler loadHandler=new LoadHandler();
        Dimensao dimensao=loadHandler.loadCentroFromCSV();
        LinkedList<Veiculo> veiculos=loadHandler.





        Dimensao dimensao = new Dimensao(20, 30);
        CentroDistribuicao centro = new CentroDistribuicao(dimensao);

        GridPane grid = new GridPane();


        for (int i = 0; i < dimensao.getComprimento(); i++) {
            for (int j = 0; j < dimensao.getLargura(); j++) {
                Rectangle cell = new Rectangle(30, 30);
                cell.setStroke(Color.BLACK);


                if (i >= centro.getLocalRecolha().getPosicao().getY() &&
                        i < (centro.getLocalRecolha().getPosicao().getY() + centro.getLocalRecolha().getDimensao().getComprimento()) &&
                        j >= centro.getLocalRecolha().getPosicao().getX() &&
                        j < (centro.getLocalRecolha().getPosicao().getX() + centro.getLocalRecolha().getDimensao().getLargura())) {
                    cell.setFill(Color.GREEN);
                } else if (i >= centro.getLocalEntrega().getPosicao().getY() &&
                        i < (centro.getLocalEntrega().getPosicao().getY() + centro.getLocalEntrega().getDimensao().getComprimento()) &&
                        j >= centro.getLocalEntrega().getPosicao().getX() &&
                        j < (centro.getLocalEntrega().getPosicao().getX() + centro.getLocalEntrega().getDimensao().getLargura())) {
                    cell.setFill(Color.BLUE);
                } else if (i >= centro.getLocalArmazenamento().getPosicao().getY() &&
                        i < (centro.getLocalArmazenamento().getPosicao().getY() + centro.getLocalArmazenamento().getDimensao().getComprimento()) &&
                        j >= centro.getLocalArmazenamento().getPosicao().getX() &&
                        j < (centro.getLocalArmazenamento().getPosicao().getX() + centro.getLocalArmazenamento().getDimensao().getLargura())) {
                    cell.setFill(Color.IVORY);
                } else {
                    cell.setFill(Color.GRAY);
                }

                grid.add(cell, j, i);
            }
        }

        primaryStage.setScene(new Scene(grid, 600, 600));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

 */