package Sensores;

/**
 * A interface Sensor representa um sensor genérico.
 * Ela define o método detectar() que deve ser implementado por todas as classes que a implementam.
 */
public interface Sensor {
    /**
     * Realiza a detecção usando o sensor.
     */
    void detectar();
}
