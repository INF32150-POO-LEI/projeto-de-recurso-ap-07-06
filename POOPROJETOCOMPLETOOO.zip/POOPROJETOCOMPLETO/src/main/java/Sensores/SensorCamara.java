package Sensores;

/**
 * Classe que representa um sensor de câmera.
 */
public class SensorCamara implements Sensor {
    private static final int ALCANCE = 30; // metros
    private static final int ANGULO_VISAO = 90; // graus

    /**
     * Método para detectar usando a câmera.
     */
    @Override
    public void detectar() {
        System.out.println("Detectando com Câmera até " + ALCANCE + " metros com um ângulo de visão de " + ANGULO_VISAO + " graus");
    }
}
