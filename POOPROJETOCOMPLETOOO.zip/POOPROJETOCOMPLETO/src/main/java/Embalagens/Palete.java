package Embalagens;

import Erros.CodigoErro;
import Erros.ProjetoIllegalArgumentException;

import java.util.LinkedList;

/**
 * A classe Palete representa uma palete como uma embalagem que herda as características de uma embalagem geral.
 * Ela também possui uma lista encadeada de caixas de cartão associadas.
 */
public class Palete extends Embalagem{
    /**
     * Construtor da classe Palete.
     */
    public Palete() {
        super();
        this.tipo = EnumEmbalagemTipo.PALETE;
        this.idFinal = tipo.toString() + (++idNumero);
        caixasDeCartao = new LinkedList<CaixaCartao>();
    }
    public double getPesoTotal() {
        double pesoTotal = 0.0;
        for (CaixaCartao caixaDeCartao : caixasDeCartao) { // Mudança para variável correta.
            pesoTotal += caixaDeCartao.getPesoTotal(); // Uso correto da variável.
        }
        return pesoTotal;
    }

    /**
     * Adiciona uma caixa de cartão à palete.
     *
     * @param caixaDeCartao a caixa de cartão a ser adicionada.
     * @throws ProjetoIllegalArgumentException se a caixa de cartão já estiver presente na palete.
     */
    public void adicionarCaixaDeCartao(CaixaCartao caixaDeCartao) {
        if (!caixasDeCartao.isEmpty() && caixasDeCartao.contains(caixaDeCartao)) {
            throw new ProjetoIllegalArgumentException(CodigoErro.PRODUTO_REPETIDO);
        } else {
            caixasDeCartao.add(caixaDeCartao);
        }
    }

    /**
     * Remove uma caixa de cartão da palete.
     *
     * @param caixaDeCartao a caixa de cartão a ser removida.
     * @throws ProjetoIllegalArgumentException se a caixa de cartão não estiver presente na palete.
     */
    public void removerCaixaDeCartao(CaixaCartao caixaDeCartao) {
        if (!caixasDeCartao.contains(caixaDeCartao)) {
            throw new ProjetoIllegalArgumentException(CodigoErro.PRODUTO_REPETIDO);
        } else {
            caixasDeCartao.remove(caixaDeCartao);
        }
    }
}
