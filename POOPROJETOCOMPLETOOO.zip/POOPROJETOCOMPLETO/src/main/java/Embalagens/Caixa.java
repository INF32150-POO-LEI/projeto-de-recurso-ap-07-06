package Embalagens;

import Erros.CodigoErro;
import Erros.ProjetoIllegalArgumentException;
import Produtos.EnumProdutoTamanho;
import Produtos.EnumProdutoTipo;
import Produtos.Produto;

import java.util.LinkedList;

/**
 * A classe Caixa representa uma caixa como uma subclasse de Embalagem e implementa a interface Embalavel.
 */
public class Caixa extends Embalagem implements Embalavel,Transportavel {

    /**
     * Construtor padrão da classe Caixa.
     * Inicializa os atributos e configura o tipo e o ID da embalagem.
     */
    public Caixa() {
        super();
        this.tipo = EnumEmbalagemTipo.CAIXA;
        this.idFinal = tipo.toString() + (++idNumero);
        produtos = new LinkedList<Produto>();
    }

    public double getPesoTotal() {
        if (!produtos.isEmpty()) {
            return produtos.get(0).getPeso();
        } else {
            return 0.0;
        }
    }
    /**
     * Método para embalar um produto na caixa.
     *
     * @param produto o produto a ser embalado na caixa.
     * @throws ProjetoIllegalArgumentException se a caixa estiver cheia ou se o tipo ou tamanho do produto não forem suportados.
     */
    @Override
    public void embalar(Produto produto) throws ProjetoIllegalArgumentException {

        if (!produtos.isEmpty()) {
            throw new ProjetoIllegalArgumentException(CodigoErro.EMBALAGEM_IS_FULL);
        }
        if (produto.getTamanho() == EnumProdutoTamanho.GRANDE || produto.getTipo() == EnumProdutoTipo.ROUPA) {
            throw new ProjetoIllegalArgumentException(CodigoErro.TYPE_NOT_SUPPORTED);
        } else {
            produtos.add(produto);
        }
    }
}
