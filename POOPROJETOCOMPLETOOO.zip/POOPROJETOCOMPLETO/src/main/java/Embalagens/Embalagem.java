package Embalagens;

import Produtos.Produto;

import java.util.LinkedList;

/**
 * A classe Embalagem é uma classe abstrata que serve como base para diferentes tipos de embalagens.
 */
public abstract class Embalagem {

    protected static int idNumero;
    protected EnumEmbalagemTipo tipo;
    protected String idFinal;
    protected LinkedList<Produto> produtos;
    protected LinkedList<CaixaCartao> caixasDeCartao;

    /**
     * Construtor da classe Embalagem.
     */
    public Embalagem() {
        this.idFinal = idFinal;
    }

    /**
     * Obtém o número do ID.
     *
     * @return o número do ID.
     */
    public static int getIdNumero() {
        return idNumero;
    }

    /**
     * Obtém o tipo de embalagem.
     *
     * @return o tipo de embalagem.
     */
    public EnumEmbalagemTipo getTipo() {
        return tipo;
    }

    /**
     * Obtém o ID final da embalagem.
     *
     * @return o ID final da embalagem.
     */
    public String getIdFinal() {
        return idFinal;
    }

    /**
     * Obtém a lista de produtos embalados na embalagem.
     *
     * @return a lista de produtos embalados na embalagem.
     */
    public LinkedList<Produto> getProdutos() {
        return produtos;
    }

    /**
     * Obtém a lista de caixas de cartão embaladas na embalagem.
     *
     * @return a lista de caixas de cartão embaladas na embalagem.
     */
    public LinkedList<CaixaCartao> getCaixasDeCartao() {
        return caixasDeCartao;
    }

    /**
     * Reinicia o número do ID para 0.
     */
    public void resetIdNumero() {
        idNumero = 0;
    }

    public void removerTodosProdutos() {
        produtos.clear();
    }
}
