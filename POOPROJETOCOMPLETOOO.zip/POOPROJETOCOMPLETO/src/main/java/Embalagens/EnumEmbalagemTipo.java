package Embalagens;

/**
 * A enumeração EnumEmbalagemTipo define os tipos possíveis de embalagem.
 */
public enum EnumEmbalagemTipo {
    SACO,       // Tipo de embalagem: Saco
    CAIXA,      // Tipo de embalagem: Caixa
    CAIXACARTAO, // Tipo de embalagem: Caixa de Cartão
    PALETE;     // Tipo de embalagem: Palete
}
