package CentroDistribuicao;

import Embalagens.Embalagem;
import PosicoesDimensoes.Dimensao;
import PosicoesDimensoes.Posicao;
import Produtos.Produto;

import java.util.LinkedList;

/**
 * A classe LocalRecolha representa um local de entrega que herda as características de um local com posição e dimensão.
 * Ele também possui um nome, bem como uma lista encadeada de embalagens.
 */
public class LocalEntrega extends Local{
    private LinkedList<Embalagem> embalagens;
    private LinkedList<Produto> produtos;
    private LinkedList<Tiles> tiles;

    /**
     * Construtor da classe LocalRecolhaEntrega.
     *
     * @param posicao   a posição do local de recolha/entrega.
     * @param dimensao  a dimensão do local de recolha/entrega.
     */
    public LocalEntrega(Posicao posicao, Dimensao dimensao) {
        super(posicao, dimensao);
        embalagens = new LinkedList<Embalagem>();
        produtos= new LinkedList<Produto>();
        this.tiles=new LinkedList<>();
    }


    /**
     * Obtém a posição do local de recolha/entrega.
     *
     * @return a posição do local de recolha/entrega.
     */
    public Posicao getPosicao() {
        return posicao;
    }

    /**
     * Define a posição do local de recolha/entrega.
     *
     * @param posicao a posição a ser definida.
     */
    public void setPosicao(Posicao posicao) {
        this.posicao = posicao;
    }

    /**
     * Obtém a dimensão do local de recolha/entrega.
     *
     * @return a dimensão do local de recolha/entrega.
     */
    public Dimensao getDimensao() {
        return dimensao;
    }

    /**
     * Define a dimensão do local de recolha/entrega.
     *
     * @param dimensao a dimensão a ser definida.
     */
    public void setDimensao(Dimensao dimensao) {
        this.dimensao = dimensao;
    }

    /**
     * Obtém a lista de embalagens no local de recolha/entrega.
     *
     * @return a lista de embalagens no local de recolha/entrega.
     */
    public LinkedList<Embalagem> getEmbalagens() {
        return embalagens;
    }

    public LinkedList<Produto> getProdutos() {
        return produtos;
    }
    public void addProduto(Produto produto) {
        this.produtos.add(produto);
    }

    public LinkedList<Tiles> getTiles() {
        return tiles;
    }
    public void addEmbalagem(Embalagem embalagem) {
        this.embalagens.add(embalagem);
    }


}
