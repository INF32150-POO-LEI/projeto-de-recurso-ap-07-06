package Erros;

/**
 * A classe ProjetoIllegalArgumentException é uma subclasse de IllegalArgumentException que é usada
 * para lançar exceções personalizadas no projeto. Ela armazena um código de erro específico.
 */
public class ProjetoIllegalArgumentException extends IllegalArgumentException {
    private final CodigoErro codigoErro;

    /**
     * Cria uma nova instância de ProjetoIllegalArgumentException com o código de erro especificado.
     *
     * @param codigoErro O código de erro associado à exceção.
     */
    public ProjetoIllegalArgumentException(CodigoErro codigoErro) {
        super(codigoErro.toString());
        this.codigoErro = codigoErro;
    }

    /**
     * Obtém o código de erro associado à exceção.
     *
     * @return O código de erro associado à exceção.
     */
    public CodigoErro getCodigoErro() {
        return codigoErro;
    }
}
