package Produtos;
/**
 * A enumeração EnumProdutoTipo define os tipos possíveis de produto.
 */
public enum EnumProdutoTipo {
    ELETRONICO, // Tipo de produto: Eletrônico
    LIVRO,      // Tipo de produto: Livro
    ACESSORIO,  // Tipo de produto: Acessório
    BRINQUEDO,  // Tipo de produto: Brinquedo
    ROUPA;      // Tipo de produto: Roupa
}
