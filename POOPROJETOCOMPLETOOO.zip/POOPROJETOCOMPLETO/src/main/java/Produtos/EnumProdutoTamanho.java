package Produtos;

/**
 * A enumeração EnumProdutoTamanho define os tamanhos possíveis para um produto.
 */
public enum EnumProdutoTamanho {
    GRANDE,   // Tamanho do produto: Grande
    PEQUENO;  // Tamanho do produto: Pequeno
}
